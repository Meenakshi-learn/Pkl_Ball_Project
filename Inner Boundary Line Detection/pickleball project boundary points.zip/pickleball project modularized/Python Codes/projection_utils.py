import numpy as np

# ============================================================
# PROJECTION UTILITY FUNCTIONS
# ============================================================

def project_line_back(line, H_inv):
    """Project line from warped space back to original image"""
    x1, y1, x2, y2 = line
    p1 = np.array([[x1, y1, 1]]).T
    p2 = np.array([[x2, y2, 1]]).T
    q1 = H_inv @ p1
    q2 = H_inv @ p2
    q1 /= q1[2]
    q2 /= q2[2]
    return int(q1[0]), int(q1[1]), int(q2[0]), int(q2[1])


def project_point_back(pt, H_inv):
    """Project point from warped space back to original image"""
    x, y = pt
    p = np.array([[x, y, 1]]).T
    q = H_inv @ p
    q /= q[2]
    return int(q[0]), int(q[1])