import cv2
import numpy as np
import os
from config import INPUT_IMAGE, OUTPUT_DIR, OUTPUT_IMAGES_DIR
from boundary_detector import detect_outer_boundary
from line_detector import detect_inner_lines
from line_diagnostics import create_diagnostic_report
from net_detector import detect_net, visualize_net, get_net_endpoints
from white_line_isolator import compare_isolation_methods
from visualizer import draw_results, create_gray_visualization
from file_utils import save_hull_config
from projection_utils import project_line_back

# ============================================================
# MAIN PIPELINE - ENHANCED WITH DIAGNOSTICS
# ============================================================

def main(use_gray_background=True,
         compare_methods=False,
         run_diagnostics=True):
    """
    Complete pickleball court detection pipeline with enhanced line detection.
    
    Args:
        use_gray_background: Draw final output on grayscale background
        compare_methods: Compare all isolation methods
        run_diagnostics: Run diagnostic analysis on detected lines
    """
    
    # Load image
    img = cv2.imread(INPUT_IMAGE)
    if img is None:
        raise FileNotFoundError(f"Image not found: {INPUT_IMAGE}")
    
    print("\n" + "="*60)
    print("PICKLEBALL COURT DETECTION PIPELINE")
    print("Enhanced Line Detection for Near-Camera Lines")
    print("="*60)
    print(f"Gray Background: {'Enabled' if use_gray_background else 'Disabled'}")
    print(f"Diagnostics: {'Enabled' if run_diagnostics else 'Disabled'}")
    print("="*60 + "\n")
    
    # OPTIONAL: Compare white line isolation methods
    if compare_methods:
        print("STEP 0: Comparing Isolation Methods")
        compare_isolation_methods(img, save_debug=True)
        print()
    
    # STEP 1: Detect outer boundary
    print("STEP 1: Boundary Detection (Gray-based)")
    inner_hull, outer_hull = detect_outer_boundary(img)
    
    if inner_hull is None:
        print("❌ Failed to detect boundary")
        print("\n[INFO] Check these debug images:")
        print(f"  - {os.path.join(OUTPUT_IMAGES_DIR, '00_original_gray.jpg')}")
        print(f"  - {os.path.join(OUTPUT_IMAGES_DIR, '01_mask.jpg')}")
        print(f"  - {os.path.join(OUTPUT_IMAGES_DIR, '02_edges.jpg')}")
        print(f"  - {os.path.join(OUTPUT_IMAGES_DIR, '03_lines.jpg')}")
        return
    
    # STEP 2: Enhanced inner line detection
    print("\nSTEP 2: Enhanced Inner Line Detection")
    print("       (Multiple passes including short near-camera lines)")
    vertical_td, horizontal_td, H_inv = detect_inner_lines(img, inner_hull, detect_short_lines=True)
    
    if not vertical_td and not horizontal_td:
        print("❌ No inner lines detected")
        return
    
    print(f"[✓] Detected {len(vertical_td)} vertical lines")
    print(f"[✓] Detected {len(horizontal_td)} horizontal lines")
    
    # STEP 3: Run diagnostics (OPTIONAL)
    if run_diagnostics:
        print("\nSTEP 3: Running Line Detection Diagnostics")
        
        # Create warped image for diagnostics
        dst = np.array([[0, 0], [600, 0], [600, 1200], [0, 1200]], dtype=np.float32)
        H, _ = cv2.findHomography(inner_hull.astype(np.float32), dst)
        warped = cv2.warpPerspective(img, H, (600, 1200))
        
        # Run diagnostic analysis
        diagnostic_info = create_diagnostic_report(
            vertical_td, 
            horizontal_td, 
            warped,
            output_dir=OUTPUT_IMAGES_DIR
        )
        
        # Check for missing lines
        if diagnostic_info['missing_vertical']:
            print(f"\n⚠️  WARNING: Possible missing vertical lines detected!")
            print(f"    Suggested X-positions: {diagnostic_info['missing_vertical']}")
            print(f"    You may need to adjust detection parameters")
        
        if diagnostic_info['missing_horizontal']:
            print(f"\n⚠️  WARNING: Possible missing horizontal lines detected!")
            print(f"    Suggested Y-positions: {diagnostic_info['missing_horizontal']}")
    
    # STEP 4: Detect net line
    print("\nSTEP 4: Net Detection")
    net_line, net_center = detect_net(img, inner_hull, H_inv)
    
    # STEP 5: Draw results on final image
    print("\nSTEP 5: Generating Final Visualization")
    final, final_points = draw_results(img, vertical_td, horizontal_td, H_inv, outer_hull, 
                                       use_gray_background=use_gray_background)
    
    # STEP 6: Add net visualization to final image
    if net_line is not None:
        x1, y1, x2, y2 = net_line
        cv2.line(final, (x1, y1), (x2, y2), (0, 255, 255), 4)
        if net_center is not None:
            cv2.circle(final, net_center, 12, (255, 0, 255), -1)
            cv2.circle(final, net_center, 14, (255, 255, 255), 2)
            cv2.putText(final, "NET", (net_center[0] + 20, net_center[1] - 15),
                       cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 3)
        
        # Get net endpoints
        left_endpoint, right_endpoint = get_net_endpoints(net_line, inner_hull)
        if left_endpoint and right_endpoint:
            cv2.circle(final, left_endpoint, 10, (255, 255, 0), -1)
            cv2.circle(final, right_endpoint, 10, (255, 255, 0), -1)
    
    # STEP 7: Create enhanced gray visualization
    if use_gray_background:
        print("\nSTEP 6: Creating Enhanced Gray Visualization")
        gray_final = create_gray_visualization(
            img, vertical_td, horizontal_td, H_inv, outer_hull,
            net_line, net_center
        )
        cv2.imwrite(os.path.join(OUTPUT_DIR, "FINAL_GRAY_ENHANCED.jpg"), gray_final)
        print(f"[✓] Enhanced gray visualization saved")
    
    # Save final output
    out_path = os.path.join(OUTPUT_DIR, "FINAL_COMBINED_OUTPUT.jpg")
    cv2.imwrite(out_path, final)
    
    # Save standalone net visualization
    if net_line is not None:
        visualize_net(img, net_line, net_center)
    
    # Save configuration
    dst = np.array([[0, 0], [600, 0], [600, 1200], [0, 1200]], dtype=np.float32)
    H, _ = cv2.findHomography(inner_hull.astype(np.float32), dst)
    save_hull_config(inner_hull, outer_hull, H)
    
    # Print comprehensive summary
    print("\n" + "="*60)
    print("✅ PROCESSING COMPLETE!")
    print("="*60)
    print(f"📍 Intersection points: {len(final_points)}")
    print(f"🔲 Outer boundary: 4 corners with 50px offset")
    print(f"\n📊 Line Detection:")
    print(f"   - Detection method: Enhanced multi-pass (near-camera optimized)")
    print(f"   - Vertical lines: {len(vertical_td)}")
    print(f"   - Horizontal lines: {len(horizontal_td)}")
    
    if net_line is not None:
        print(f"\n🎾 Net Detection:")
        print(f"   - Center position: {net_center}")
    else:
        print("\n⚠️  Net detection failed")
    
    print(f"\n💾 Output Files:")
    print(f"   - Final image: {out_path}")
    if use_gray_background:
        print(f"   - Enhanced gray: {os.path.join(OUTPUT_DIR, 'FINAL_GRAY_ENHANCED.jpg')}")
    print(f"   - Debug images: {OUTPUT_IMAGES_DIR}/")
    
    if run_diagnostics:
        print(f"\n🔍 Diagnostic Files:")
        print(f"   - Vertical heatmap: diagnostic_vertical_heatmap.jpg")
        print(f"   - Horizontal heatmap: diagnostic_horizontal_heatmap.jpg")
        print(f"   - Grid analysis: diagnostic_grid_analysis.jpg")
        print(f"   - Coverage map: diagnostic_coverage_map.jpg")
    
    print(f"\n   - Configuration: {os.path.join(OUTPUT_DIR, 'hull_config.json')}")
    print("="*60 + "\n")
    
    # Final recommendation
    if run_diagnostics and diagnostic_info:
        if diagnostic_info['missing_vertical'] or diagnostic_info['missing_horizontal']:
            print("💡 RECOMMENDATION:")
            print("   Some lines may be missing. Check the diagnostic images to verify.")
            print("   If lines are truly missing, try adjusting these in line_detector.py:")
            print("   - Increase gap_threshold (currently 50)")
            print("   - Decrease minLineLength in HoughLinesP (currently 40-120)")
            print("   - Increase position_tolerance (currently 15)")
        else:
            print("✅ All expected lines detected successfully!")
    
    print()


# ============================================================
# RUN WITH CONFIGURABLE OPTIONS
# ============================================================

if __name__ == "__main__":
    # Run pipeline with enhanced detection and diagnostics
    main(
        use_gray_background=True,   # Draw on grayscale background
        compare_methods=False,      # Set True to compare isolation methods
        run_diagnostics=True        # Enable diagnostic analysis
    )
    
    # Alternative configurations:
    
    # Quick run without diagnostics:
    # main(use_gray_background=True, run_diagnostics=False)
    
    # Full analysis with method comparison:
    # main(use_gray_background=True, compare_methods=True, run_diagnostics=True)