import cv2
import numpy as np
import os
from projection_utils import project_line_back, project_point_back
from geometry_utils import intersect_lines, deduplicate_points
from config import OUTPUT_IMAGES_DIR

# ============================================================
# VISUALIZATION FUNCTIONS WITH GRAY BACKGROUND
# ============================================================

def draw_results(img, vertical_td, horizontal_td, H_inv, outer_hull, use_gray_background=True):
    """
    Draw all detected lines, intersections, and boundaries on the image.
    
    Args:
        img: Original BGR image
        vertical_td: List of vertical lines in top-down view
        horizontal_td: List of horizontal lines in top-down view
        H_inv: Inverse homography matrix
        outer_hull: Outer boundary polygon
        use_gray_background: If True, draw on grayscale image
    
    Returns:
        final: Final visualization image
        final_points: List of intersection points
    """
    
    # Create base image - either grayscale or color
    if use_gray_background:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        final = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        vertical_img = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        horizontal_img = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        both_lines_img = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        hull_img = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    else:
        final = img.copy()
        vertical_img = img.copy()
        horizontal_img = img.copy()
        both_lines_img = img.copy()
        hull_img = img.copy()
    
    raw_points = []
    
    # Draw vertical lines → BLUE
    for v in vertical_td:
        x1, y1, x2, y2 = project_line_back(v, H_inv)
        cv2.line(final, (x1, y1), (x2, y2), (255, 0, 0), 2)
        cv2.line(vertical_img, (x1, y1), (x2, y2), (255, 0, 0), 2)
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "05_vertical_lines.jpg"), vertical_img)
    
    # Draw horizontal lines → GREEN
    for h_line in horizontal_td:
        x1, y1, x2, y2 = project_line_back(h_line, H_inv)
        cv2.line(final, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.line(horizontal_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "06_horizontal_lines.jpg"), horizontal_img)
    
    # Draw both lines together
    for v in vertical_td:
        x1, y1, x2, y2 = project_line_back(v, H_inv)
        cv2.line(both_lines_img, (x1, y1), (x2, y2), (255, 0, 0), 2)
    for h_line in horizontal_td:
        x1, y1, x2, y2 = project_line_back(h_line, H_inv)
        cv2.line(both_lines_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "07_all_lines.jpg"), both_lines_img)
    
    # Collect intersection points
    for v in vertical_td:
        for h_line in horizontal_td:
            pt = intersect_lines(v, h_line)
            if pt is not None:
                raw_points.append(project_point_back(pt, H_inv))
    
    # Deduplicate points
    final_points = deduplicate_points(raw_points, dist_thresh=25)
    
    # Draw points with larger circles and better contrast
    points_img = both_lines_img.copy()
    for i, (x, y) in enumerate(final_points):
        # Draw point with outline for better visibility
        cv2.circle(final, (x, y), 8, (0, 255, 255), -1)
        cv2.circle(final, (x, y), 9, (0, 0, 0), 2)  # Black outline
        
        # Label with better contrast
        cv2.putText(final, f"P{i}", (x+10, y-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(final, f"P{i}", (x+10, y-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1)
        
        # Same for points image
        cv2.circle(points_img, (x, y), 8, (0, 255, 255), -1)
        cv2.circle(points_img, (x, y), 9, (0, 0, 0), 2)
        cv2.putText(points_img, f"P{i}", (x+10, y-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "08_intersection_points.jpg"), points_img)
    
    # Draw outer hull with thicker line for visibility
    cv2.polylines(hull_img, [outer_hull], True, (0, 0, 255), 4)
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "09_outer_hull.jpg"), hull_img)
    
    # Draw outer hull on final image
    cv2.polylines(final, [outer_hull], True, (0, 0, 255), 4)
    
    return final, final_points


def create_gray_visualization(img, vertical_td, horizontal_td, H_inv, outer_hull, 
                               net_line=None, net_center=None):
    """
    Create a clean grayscale visualization with colored lines and boundaries.
    
    Args:
        img: Original BGR image
        vertical_td: Vertical lines
        horizontal_td: Horizontal lines
        H_inv: Inverse homography
        outer_hull: Outer boundary
        net_line: Net line (optional)
        net_center: Net center point (optional)
    
    Returns:
        Final grayscale visualization with colored overlays
    """
    
    # Convert to grayscale and back to BGR for color drawing
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Apply slight contrast enhancement
    clahe = cv2.createCLAHE(clipLimit=1.5, tileGridSize=(8, 8))
    gray_enhanced = clahe.apply(gray)
    
    # Convert back to BGR
    final = cv2.cvtColor(gray_enhanced, cv2.COLOR_GRAY2BGR)
    
    # Draw vertical lines (BLUE)
    for v in vertical_td:
        x1, y1, x2, y2 = project_line_back(v, H_inv)
        cv2.line(final, (x1, y1), (x2, y2), (255, 100, 0), 3)  # Bright blue
    
    # Draw horizontal lines (GREEN)
    for h_line in horizontal_td:
        x1, y1, x2, y2 = project_line_back(h_line, H_inv)
        cv2.line(final, (x1, y1), (x2, y2), (0, 255, 100), 3)  # Bright green
    
    # Draw intersection points
    raw_points = []
    for v in vertical_td:
        for h_line in horizontal_td:
            pt = intersect_lines(v, h_line)
            if pt is not None:
                raw_points.append(project_point_back(pt, H_inv))
    
    final_points = deduplicate_points(raw_points, dist_thresh=25)
    
    for i, (x, y) in enumerate(final_points):
        cv2.circle(final, (x, y), 8, (0, 255, 255), -1)  # Cyan
        cv2.circle(final, (x, y), 10, (255, 255, 255), 2)  # White outline
    
    # Draw outer boundary (RED)
    cv2.polylines(final, [outer_hull], True, (0, 100, 255), 5)  # Bright red
    
    # Draw net if available (YELLOW)
    if net_line is not None:
        x1, y1, x2, y2 = net_line
        cv2.line(final, (x1, y1), (x2, y2), (0, 255, 255), 4)  # Yellow
        
        if net_center is not None:
            cv2.circle(final, net_center, 12, (255, 0, 255), -1)  # Magenta
            cv2.circle(final, net_center, 14, (255, 255, 255), 2)  # White outline
            cv2.putText(final, "NET", (net_center[0] + 20, net_center[1] - 15),
                       cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 3)
    
    return final