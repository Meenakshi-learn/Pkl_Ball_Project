import cv2
import numpy as np
import os
from config import OUTPUT_IMAGES_DIR

# ============================================================
# LINE DETECTION DIAGNOSTICS MODULE
# ============================================================

def create_heatmap_visualization(img, lines, orientation='vertical'):
    """
    Create a heatmap showing where lines are detected.
    Helps identify missing regions.
    
    Args:
        img: Input image
        lines: List of detected lines
        orientation: 'vertical' or 'horizontal'
    
    Returns:
        Heatmap visualization
    """
    
    h, w = img.shape[:2]
    heatmap = np.zeros((h, w), dtype=np.float32)
    
    # Draw each line with Gaussian blur to create heatmap
    for line in lines:
        x1, y1, x2, y2 = line
        
        # Create temporary image for this line
        temp = np.zeros((h, w), dtype=np.uint8)
        cv2.line(temp, (x1, y1), (x2, y2), 255, 5)
        
        # Blur to create heat effect
        temp_blur = cv2.GaussianBlur(temp, (21, 21), 0)
        heatmap += temp_blur.astype(np.float32)
    
    # Normalize and convert to color
    if heatmap.max() > 0:
        heatmap = (heatmap / heatmap.max() * 255).astype(np.uint8)
    else:
        heatmap = heatmap.astype(np.uint8)
    
    # Apply colormap
    heatmap_color = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
    
    # Blend with original image
    if len(img.shape) == 2:
        img_color = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    else:
        img_color = img
    
    result = cv2.addWeighted(img_color, 0.5, heatmap_color, 0.5, 0)
    
    return result


def analyze_line_distribution(lines, orientation='vertical', image_shape=(1200, 600)):
    """
    Analyze the spatial distribution of detected lines.
    
    Args:
        lines: List of detected lines
        orientation: 'vertical' or 'horizontal'
        image_shape: Shape of the warped image (h, w)
    
    Returns:
        Dictionary with distribution statistics
    """
    
    h, w = image_shape
    
    if not lines:
        return {
            'count': 0,
            'positions': [],
            'lengths': [],
            'gaps': []
        }
    
    positions = []
    lengths = []
    
    for line in lines:
        x1, y1, x2, y2 = line
        length = np.hypot(x2 - x1, y2 - y1)
        lengths.append(length)
        
        if orientation == 'vertical':
            pos = (x1 + x2) / 2
        else:
            pos = (y1 + y2) / 2
        
        positions.append(pos)
    
    # Sort positions
    positions_sorted = sorted(positions)
    
    # Calculate gaps between consecutive lines
    gaps = []
    for i in range(len(positions_sorted) - 1):
        gap = positions_sorted[i + 1] - positions_sorted[i]
        gaps.append(gap)
    
    stats = {
        'count': len(lines),
        'positions': positions_sorted,
        'lengths': lengths,
        'gaps': gaps,
        'min_length': min(lengths) if lengths else 0,
        'max_length': max(lengths) if lengths else 0,
        'avg_length': np.mean(lengths) if lengths else 0,
        'avg_gap': np.mean(gaps) if gaps else 0
    }
    
    return stats


def create_diagnostic_report(vertical_lines, horizontal_lines, warped_img, output_dir=OUTPUT_IMAGES_DIR):
    """
    Create comprehensive diagnostic visualizations and report.
    
    Args:
        vertical_lines: List of vertical lines
        horizontal_lines: List of horizontal lines
        warped_img: Top-down warped image
        output_dir: Directory to save diagnostics
    
    Returns:
        Dictionary with diagnostic information
    """
    
    print("\n" + "="*60)
    print("LINE DETECTION DIAGNOSTICS")
    print("="*60 + "\n")
    
    h, w = warped_img.shape[:2]
    
    # Analyze distributions
    v_stats = analyze_line_distribution(vertical_lines, 'vertical', (h, w))
    h_stats = analyze_line_distribution(horizontal_lines, 'horizontal', (h, w))
    
    print("[VERTICAL LINES]")
    print(f"  Count: {v_stats['count']}")
    print(f"  Lengths: min={v_stats['min_length']:.1f}, max={v_stats['max_length']:.1f}, avg={v_stats['avg_length']:.1f}")
    if v_stats['gaps']:
        print(f"  Gaps: avg={v_stats['avg_gap']:.1f}, max={max(v_stats['gaps']):.1f}")
    print(f"  X-positions: {[f'{p:.0f}' for p in v_stats['positions']]}")
    
    print(f"\n[HORIZONTAL LINES]")
    print(f"  Count: {h_stats['count']}")
    print(f"  Lengths: min={h_stats['min_length']:.1f}, max={h_stats['max_length']:.1f}, avg={h_stats['avg_length']:.1f}")
    if h_stats['gaps']:
        print(f"  Gaps: avg={h_stats['avg_gap']:.1f}, max={max(h_stats['gaps']):.1f}")
    print(f"  Y-positions: {[f'{p:.0f}' for p in h_stats['positions']]}")
    
    # Create heatmap visualizations
    print("\n[Creating heatmap visualizations...]")
    
    v_heatmap = create_heatmap_visualization(warped_img, vertical_lines, 'vertical')
    h_heatmap = create_heatmap_visualization(warped_img, horizontal_lines, 'horizontal')
    
    cv2.imwrite(os.path.join(output_dir, "diagnostic_vertical_heatmap.jpg"), v_heatmap)
    cv2.imwrite(os.path.join(output_dir, "diagnostic_horizontal_heatmap.jpg"), h_heatmap)
    
    # Create grid visualization
    print("[Creating grid analysis...]")
    grid_vis = create_grid_analysis(warped_img, vertical_lines, horizontal_lines)
    cv2.imwrite(os.path.join(output_dir, "diagnostic_grid_analysis.jpg"), grid_vis)
    
    # Create coverage map
    print("[Creating coverage map...]")
    coverage_map = create_coverage_map(warped_img, vertical_lines, horizontal_lines)
    cv2.imwrite(os.path.join(output_dir, "diagnostic_coverage_map.jpg"), coverage_map)
    
    # Identify potential missing lines
    print("\n[MISSING LINE ANALYSIS]")
    missing_vertical = identify_missing_lines(v_stats, 'vertical', (h, w))
    missing_horizontal = identify_missing_lines(h_stats, 'horizontal', (h, w))
    
    if missing_vertical:
        print(f"⚠ Potentially missing vertical lines at X-positions: {missing_vertical}")
    else:
        print("✓ Vertical line distribution looks good")
    
    if missing_horizontal:
        print(f"⚠ Potentially missing horizontal lines at Y-positions: {missing_horizontal}")
    else:
        print("✓ Horizontal line distribution looks good")
    
    print("\n" + "="*60)
    print("DIAGNOSTICS COMPLETE")
    print("="*60 + "\n")
    
    return {
        'vertical': v_stats,
        'horizontal': h_stats,
        'missing_vertical': missing_vertical,
        'missing_horizontal': missing_horizontal
    }


def create_grid_analysis(img, vertical_lines, horizontal_lines):
    """
    Create a grid showing line positions with measurements.
    """
    
    h, w = img.shape[:2]
    
    # Convert to color if grayscale
    if len(img.shape) == 2:
        result = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    else:
        result = img.copy()
    
    # Draw vertical lines with labels
    for i, line in enumerate(vertical_lines):
        x1, y1, x2, y2 = line
        x_pos = (x1 + x2) // 2
        
        # Draw line
        cv2.line(result, (x1, y1), (x2, y2), (255, 0, 0), 2)
        
        # Draw position marker at top
        cv2.line(result, (x_pos, 0), (x_pos, 30), (255, 255, 0), 2)
        cv2.putText(result, f"V{i}", (x_pos - 15, 20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 2)
        cv2.putText(result, f"x={x_pos}", (x_pos - 20, 45),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    
    # Draw horizontal lines with labels
    for i, line in enumerate(horizontal_lines):
        x1, y1, x2, y2 = line
        y_pos = (y1 + y2) // 2
        
        # Draw line
        cv2.line(result, (x1, y1), (x2, y2), (0, 255, 0), 2)
        
        # Draw position marker at left
        cv2.line(result, (0, y_pos), (30, y_pos), (0, 255, 255), 2)
        cv2.putText(result, f"H{i}", (5, y_pos + 5),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 2)
    
    return result


def create_coverage_map(img, vertical_lines, horizontal_lines):
    """
    Create a map showing where intersections occur.
    """
    
    h, w = img.shape[:2]
    
    # Create semi-transparent overlay
    overlay = np.zeros((h, w, 3), dtype=np.uint8)
    
    # Draw thick lines on overlay
    for line in vertical_lines:
        x1, y1, x2, y2 = line
        cv2.line(overlay, (x1, y1), (x2, y2), (255, 0, 0), 10)
    
    for line in horizontal_lines:
        x1, y1, x2, y2 = line
        cv2.line(overlay, (x1, y1), (x2, y2), (0, 255, 0), 10)
    
    # Convert original to color
    if len(img.shape) == 2:
        img_color = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    else:
        img_color = img.copy()
    
    # Blend
    result = cv2.addWeighted(img_color, 0.6, overlay, 0.4, 0)
    
    return result


def identify_missing_lines(stats, orientation='vertical', image_shape=(1200, 600)):
    """
    Identify potential gaps where lines might be missing.
    """
    
    if stats['count'] < 2:
        return []
    
    h, w = image_shape
    max_dimension = w if orientation == 'vertical' else h
    
    # Expected gap based on typical court layout
    if stats['avg_gap'] > 0:
        expected_gap = stats['avg_gap']
    else:
        return []
    
    # Look for large gaps (more than 1.5x expected)
    threshold = expected_gap * 1.8
    
    missing_positions = []
    positions = stats['positions']
    
    for i in range(len(positions) - 1):
        gap = positions[i + 1] - positions[i]
        if gap > threshold:
            # Estimate missing line position
            missing_pos = int((positions[i] + positions[i + 1]) / 2)
            missing_positions.append(missing_pos)
    
    return missing_positions