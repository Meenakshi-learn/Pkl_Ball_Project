import json
from config import JSON_PATH

# ============================================================
# FILE I/O UTILITY FUNCTIONS
# ============================================================

def save_hull_config(inner_hull, outer_hull, H_matrix, filepath=JSON_PATH):
    """Save detected hulls and homography matrix to JSON"""
    config = {
        "inner_hull": inner_hull.tolist(),
        "outer_hull": outer_hull.tolist(),
        "homography": H_matrix.tolist() if H_matrix is not None else None
    }
    with open(filepath, "w") as f:
        json.dump(config, f, indent=2)
    print(f"[✓] JSON saved at: {filepath}")