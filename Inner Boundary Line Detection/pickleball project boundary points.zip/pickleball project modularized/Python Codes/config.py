import os

# ============================================================
# CONFIGURATION
# ============================================================

INPUT_IMAGE = r"C:\Users\Niranjan\Downloads\Tennis 1.jpg"
OUTPUT_DIR = r"C:\pickleball boundary\pickleball project modularized\output1"
OUTPUT_IMAGES_DIR = os.path.join(OUTPUT_DIR, "output_images")
JSON_PATH = os.path.join(OUTPUT_DIR, "hull_config.json")

# Create directories
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(OUTPUT_IMAGES_DIR, exist_ok=True)