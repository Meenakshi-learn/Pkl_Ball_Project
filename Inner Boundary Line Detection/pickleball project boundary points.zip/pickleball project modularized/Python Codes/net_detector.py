import cv2
import numpy as np
import os
from config import OUTPUT_IMAGES_DIR
from projection_utils import project_line_back

# ============================================================
# NET DETECTION MODULE
# ============================================================

def detect_net(img, inner_hull, H_inv):
    """
    Detect the net line in the pickleball court.
    
    Args:
        img: Original input image
        inner_hull: 4 corner points of the court boundary
        H_inv: Inverse homography matrix for projection back to original image
    
    Returns:
        net_line: Tuple (x1, y1, x2, y2) of net line in original image coordinates
        net_center: Tuple (x, y) of net center point in original image
    """
    
    print("[...] Detecting Net Line")
    
    # Create homography transformation to top-down view
    dst = np.array([[0, 0], [600, 0], [600, 1200], [0, 1200]], dtype=np.float32)
    H, _ = cv2.findHomography(inner_hull.astype(np.float32), dst)
    
    # Warp to top-down view
    warped = cv2.warpPerspective(img, H, (600, 1200))
    
    # Convert to grayscale and detect white lines
    gray = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
    _, bw = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)
    
    # Edge detection
    edges = cv2.Canny(bw, 50, 150)
    
    # Hough line detection for horizontal lines
    lines = cv2.HoughLinesP(
        edges, 1, np.pi/180,
        threshold=100,
        minLineLength=150,
        maxLineGap=30
    )
    
    if lines is None:
        print("⚠ No lines detected for net")
        return None, None
    
    # Filter for horizontal lines near the center
    h, w = warped.shape[:2]
    mid_y = h // 2
    center_threshold = 100  # pixels from center
    
    horizontal_lines = []
    net_debug = warped.copy()
    
    for line in lines:
        x1, y1, x2, y2 = line[0]
        angle = abs(np.degrees(np.arctan2(y2 - y1, x2 - x1)))
        
        # Check if line is horizontal (angle close to 0 or 180)
        if angle < 5 or angle > 175:
            # Check if line is near the center (net location)
            line_center_y = (y1 + y2) // 2
            if abs(line_center_y - mid_y) < center_threshold:
                horizontal_lines.append((x1, y1, x2, y2, abs(line_center_y - mid_y)))
                cv2.line(net_debug, (x1, y1), (x2, y2), (0, 255, 0), 2)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "10_net_candidates.jpg"), net_debug)
    
    if not horizontal_lines:
        print("⚠ No horizontal lines found near court center")
        return None, None
    
    # Sort by proximity to center (closest first)
    horizontal_lines.sort(key=lambda x: x[4])
    
    # Take the line closest to center as the net
    net_line_td = horizontal_lines[0][:4]  # (x1, y1, x2, y2) in top-down view
    
    # Extend the line to full court width for better visualization
    x1_td, y1_td, x2_td, y2_td = net_line_td
    avg_y = (y1_td + y2_td) // 2
    net_line_td_extended = (0, avg_y, w, avg_y)
    
    # Project back to original image coordinates
    net_line_orig = project_line_back(net_line_td_extended, H_inv)
    
    # Calculate net center point
    x1_orig, y1_orig, x2_orig, y2_orig = net_line_orig
    net_center = ((x1_orig + x2_orig) // 2, (y1_orig + y2_orig) // 2)
    
    print(f"[✓] Net detected at y={avg_y} in top-down view")
    print(f"[✓] Net center in original image: {net_center}")
    
    return net_line_orig, net_center


def visualize_net(img, net_line, net_center, output_filename="11_net_detection.jpg"):
    """
    Draw the detected net line and center point on the image.
    
    Args:
        img: Input image
        net_line: Tuple (x1, y1, x2, y2) of net line coordinates
        net_center: Tuple (x, y) of net center point
        output_filename: Name of output file to save
    
    Returns:
        Image with net visualization
    """
    
    if net_line is None or net_center is None:
        print("⚠ No net to visualize")
        return img
    
    result = img.copy()
    x1, y1, x2, y2 = net_line
    
    # Draw net line in bright cyan/yellow
    cv2.line(result, (x1, y1), (x2, y2), (0, 255, 255), 3)
    
    # Draw net center point
    cv2.circle(result, net_center, 10, (255, 0, 255), -1)
    cv2.putText(result, "NET", (net_center[0] + 15, net_center[1] - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    
    # Save visualization
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, output_filename), result)
    print(f"[✓] Net visualization saved: {output_filename}")
    
    return result


def get_net_endpoints(net_line, inner_hull):
    """
    Get the intersection points of the net with the court sidelines.
    
    Args:
        net_line: Tuple (x1, y1, x2, y2) of net line
        inner_hull: 4 corner points of court boundary [TL, TR, BR, BL]
    
    Returns:
        Tuple of (left_endpoint, right_endpoint) as (x, y) coordinates
    """
    
    if net_line is None:
        return None, None
    
    x1, y1, x2, y2 = net_line
    
    # Extract left and right sidelines from inner hull
    # inner_hull order: [TL, TR, BR, BL]
    left_sideline = (inner_hull[0][0], inner_hull[0][1], 
                     inner_hull[3][0], inner_hull[3][1])  # TL to BL
    right_sideline = (inner_hull[1][0], inner_hull[1][1], 
                      inner_hull[2][0], inner_hull[2][1])  # TR to BR
    
    # Find intersections
    from geometry_utils import line_intersection
    
    left_endpoint = line_intersection(net_line, left_sideline)
    right_endpoint = line_intersection(net_line, right_sideline)
    
    return left_endpoint, right_endpoint