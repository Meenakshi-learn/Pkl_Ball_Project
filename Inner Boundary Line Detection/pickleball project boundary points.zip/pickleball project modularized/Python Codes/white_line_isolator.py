import cv2
import numpy as np
import os
from config import OUTPUT_IMAGES_DIR

# ============================================================
# WHITE LINE ISOLATION METHODS
# ============================================================

def isolate_white_lines(img, brightness_thresh=200, save_debug=False):
    """
    Simple white line isolation using brightness thresholding.
    
    Args:
        img: Input BGR image
        brightness_thresh: Minimum brightness value (0-255)
        save_debug: Whether to save debug images
    
    Returns:
        white_mask: Binary mask of white lines
        debug_img: Color visualization of mask
    """
    
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Simple brightness threshold
    _, white_mask = cv2.threshold(gray, brightness_thresh, 255, cv2.THRESH_BINARY)
    
    # Clean up noise
    kernel = np.ones((3, 3), np.uint8)
    white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_OPEN, kernel, iterations=1)
    white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_CLOSE, kernel, iterations=2)
    
    # Create debug visualization
    debug_img = cv2.cvtColor(white_mask, cv2.COLOR_GRAY2BGR)
    
    if save_debug:
        cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "white_lines_simple.jpg"), white_mask)
        print("[DEBUG] Saved: white_lines_simple.jpg")
    
    return white_mask, debug_img


def isolate_white_lines_advanced(img, brightness_thresh=200, 
                                  adaptive_enabled=True, 
                                  clahe_enabled=True,
                                  save_debug=False):
    """
    Advanced white line isolation with CLAHE and adaptive thresholding.
    
    Args:
        img: Input BGR image
        brightness_thresh: Minimum brightness value (0-255)
        adaptive_enabled: Use adaptive thresholding
        clahe_enabled: Use CLAHE histogram equalization
        save_debug: Whether to save debug images
    
    Returns:
        white_mask: Binary mask of white lines
        debug_img: Color visualization of mask
    """
    
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Apply CLAHE for better contrast
    if clahe_enabled:
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        gray = clahe.apply(gray)
        
        if save_debug:
            cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "white_lines_clahe.jpg"), gray)
    
    # Method 1: Global threshold
    _, mask_global = cv2.threshold(gray, brightness_thresh, 255, cv2.THRESH_BINARY)
    
    # Method 2: Adaptive threshold (if enabled)
    if adaptive_enabled:
        mask_adaptive = cv2.adaptiveThreshold(
            gray, 255, 
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
            cv2.THRESH_BINARY, 
            blockSize=15, 
            C=-5
        )
        
        # Combine both methods
        white_mask = cv2.bitwise_or(mask_global, mask_adaptive)
    else:
        white_mask = mask_global
    
    # Clean up noise with morphology
    kernel = np.ones((3, 3), np.uint8)
    white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_OPEN, kernel, iterations=1)
    white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_CLOSE, kernel, iterations=2)
    
    # Create debug visualization
    debug_img = cv2.cvtColor(white_mask, cv2.COLOR_GRAY2BGR)
    
    if save_debug:
        cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "white_lines_advanced.jpg"), white_mask)
        print("[DEBUG] Saved: white_lines_advanced.jpg")
    
    return white_mask, debug_img


def isolate_white_lines_hsv(img, saturation_thresh=40, 
                             value_thresh=180,
                             save_debug=False):
    """
    White line isolation using HSV color space.
    Looks for low saturation + high value (white).
    
    Args:
        img: Input BGR image
        saturation_thresh: Maximum saturation (0-255, lower = more white)
        value_thresh: Minimum value/brightness (0-255)
        save_debug: Whether to save debug images
    
    Returns:
        white_mask: Binary mask of white lines
        debug_img: Color visualization of mask
    """
    
    # Convert to HSV
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    
    # Extract H, S, V channels
    h, s, v = cv2.split(hsv)
    
    # White = low saturation + high value
    low_sat_mask = cv2.threshold(s, saturation_thresh, 255, cv2.THRESH_BINARY_INV)[1]
    high_val_mask = cv2.threshold(v, value_thresh, 255, cv2.THRESH_BINARY)[1]
    
    # Combine conditions
    white_mask = cv2.bitwise_and(low_sat_mask, high_val_mask)
    
    # Clean up noise
    kernel = np.ones((3, 3), np.uint8)
    white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_OPEN, kernel, iterations=1)
    white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_CLOSE, kernel, iterations=2)
    
    # Create debug visualization
    debug_img = cv2.cvtColor(white_mask, cv2.COLOR_GRAY2BGR)
    
    if save_debug:
        cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "white_lines_hsv.jpg"), white_mask)
        print("[DEBUG] Saved: white_lines_hsv.jpg")
    
    return white_mask, debug_img


def compare_isolation_methods(img, save_debug=True):
    """
    Compare all three white line isolation methods side by side.
    
    Args:
        img: Input BGR image
        save_debug: Whether to save comparison images
    
    Returns:
        Dictionary with results from all three methods
    """
    
    print("\n" + "="*60)
    print("COMPARING WHITE LINE ISOLATION METHODS")
    print("="*60 + "\n")
    
    # Method 1: Simple
    print("[Method 1] Simple brightness thresholding...")
    mask_simple, debug_simple = isolate_white_lines(img, brightness_thresh=200, save_debug=save_debug)
    
    # Method 2: Advanced
    print("[Method 2] Advanced (CLAHE + Adaptive)...")
    mask_advanced, debug_advanced = isolate_white_lines_advanced(
        img, 
        brightness_thresh=200,
        adaptive_enabled=True,
        clahe_enabled=True,
        save_debug=save_debug
    )
    
    # Method 3: HSV
    print("[Method 3] HSV color space filtering...")
    mask_hsv, debug_hsv = isolate_white_lines_hsv(
        img,
        saturation_thresh=40,
        value_thresh=180,
        save_debug=save_debug
    )
    
    # Create side-by-side comparison
    if save_debug:
        h, w = img.shape[:2]
        comparison = np.zeros((h, w*3, 3), dtype=np.uint8)
        
        comparison[:, 0:w] = debug_simple
        comparison[:, w:2*w] = debug_advanced
        comparison[:, 2*w:3*w] = debug_hsv
        
        # Add labels
        cv2.putText(comparison, "Simple", (w//2 - 50, 40),
                   cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 0), 2)
        cv2.putText(comparison, "Advanced", (w + w//2 - 70, 40),
                   cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 0), 2)
        cv2.putText(comparison, "HSV", (2*w + w//2 - 40, 40),
                   cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 0), 2)
        
        cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "white_lines_comparison.jpg"), comparison)
        print("\n[✓] Comparison saved: white_lines_comparison.jpg")
    
    print("\n" + "="*60)
    print("COMPARISON COMPLETE")
    print("="*60 + "\n")
    
    return {
        'simple': (mask_simple, debug_simple),
        'advanced': (mask_advanced, debug_advanced),
        'hsv': (mask_hsv, debug_hsv)
    }