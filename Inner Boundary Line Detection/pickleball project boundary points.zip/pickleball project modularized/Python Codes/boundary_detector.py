import cv2
import numpy as np
import os
from config import OUTPUT_IMAGES_DIR
from geometry_utils import line_intersection, order_points_clockwise, offset_polygon

# ============================================================
# IMPROVED OUTER BOUNDARY DETECTION - FULL COURT
# ============================================================

def detect_outer_boundary(img, use_white_isolation=True, isolation_method='advanced'):
    """
    Detect the 4 corner points of the FULL court boundary.
    Improved to avoid detecting net as boundary.
    
    Args:
        img: Input BGR image
        use_white_isolation: Whether to use white line isolation preprocessing
        isolation_method: 'simple', 'advanced', or 'hsv'
    
    Returns:
        inner_hull: 4 corner points of court boundary
        outer_hull: Expanded boundary with offset
    """
    
    print("[...] Detecting Outer Boundary (Full Court - 4 Corners)")
    
    h, w = img.shape[:2]
    
    # STEP 1: Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "00_original_gray.jpg"), gray)
    
    # STEP 2: Apply CLAHE for better contrast
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    gray_enhanced = clahe.apply(gray)
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "00_gray_clahe.jpg"), gray_enhanced)
    
    # STEP 3: Reduce noise before thresholding
    gray_blurred = cv2.GaussianBlur(gray_enhanced, (5, 5), 0)
    
    # STEP 4: Create mask using multiple thresholding methods
    # Method 1: Adaptive threshold
    mask_adaptive = cv2.adaptiveThreshold(
        gray_blurred, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        blockSize=15,
        C=2
    )
    
    # Method 2: Otsu's threshold
    _, mask_otsu = cv2.threshold(gray_blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    # Method 3: High threshold for very bright lines
    _, mask_bright = cv2.threshold(gray_enhanced, 200, 255, cv2.THRESH_BINARY)
    
    # Combine all masks
    combined_mask = cv2.bitwise_or(mask_adaptive, mask_otsu)
    combined_mask = cv2.bitwise_or(combined_mask, mask_bright)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "00_mask_adaptive.jpg"), mask_adaptive)
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "00_mask_otsu.jpg"), mask_otsu)
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "00_mask_bright.jpg"), mask_bright)
    
    # STEP 5: Clean up mask with morphology
    kernel = np.ones((5, 5), np.uint8)
    combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_CLOSE, kernel, iterations=3)
    combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_OPEN, kernel, iterations=2)
    
    # Remove small noise
    kernel_small = np.ones((3, 3), np.uint8)
    combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_OPEN, kernel_small, iterations=1)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "01_mask.jpg"), combined_mask)
    
    # STEP 6: Edge detection
    edges = cv2.Canny(combined_mask, 50, 150, apertureSize=3)
    
    # Also try edges on original enhanced gray
    edges_gray = cv2.Canny(gray_enhanced, 30, 100, apertureSize=3)
    edges_combined = cv2.bitwise_or(edges, edges_gray)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "02_edges.jpg"), edges_combined)
    
    # Print diagnostics
    edge_pixels = np.count_nonzero(edges_combined)
    print(f"[DEBUG] Edge pixels detected: {edge_pixels}")
    
    # STEP 7: Hough line detection with parameters tuned for outer boundaries
    lines = cv2.HoughLinesP(
        edges_combined, 
        rho=1, 
        theta=np.pi / 180,
        threshold=80,  # Higher threshold for stronger lines
        minLineLength=min(h, w) // 4,  # Longer lines (at least 1/4 image size)
        maxLineGap=50
    )
    
    if lines is None:
        print("⚠ No lines detected with initial parameters")
        print("[INFO] Trying with more relaxed parameters...")
        
        lines = cv2.HoughLinesP(
            edges_combined, 
            rho=1, 
            theta=np.pi / 180,
            threshold=50,
            minLineLength=min(h, w) // 6,
            maxLineGap=80
        )
        
        if lines is None:
            print("❌ Still no lines detected")
            return None, None
    
    print(f"[INFO] Total lines detected: {len(lines)}")
    
    # STEP 8: Classify and filter lines
    vertical_lines = []
    horizontal_lines = []
    
    line_debug = img.copy()
    
    # Calculate minimum line length threshold (longer lines = boundaries)
    min_boundary_length = min(h, w) * 0.3  # At least 30% of image dimension
    
    for line in lines:
        x1, y1, x2, y2 = line[0]
        angle = abs(np.degrees(np.arctan2(y2 - y1, x2 - x1)))
        length = np.hypot(x2 - x1, y2 - y1)
        
        # Only consider longer lines for boundaries
        if length < min_boundary_length:
            continue
        
        if 70 < angle < 110:  # Vertical
            vertical_lines.append((x1, y1, x2, y2, length))
            cv2.line(line_debug, (x1, y1), (x2, y2), (255, 0, 0), 2)
        elif angle < 20 or angle > 160:  # Horizontal
            horizontal_lines.append((x1, y1, x2, y2, length))
            cv2.line(line_debug, (x1, y1), (x2, y2), (0, 255, 0), 2)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "03_lines.jpg"), line_debug)
    
    print(f"[INFO] Found {len(vertical_lines)} vertical, {len(horizontal_lines)} horizontal boundary lines")
    
    if len(vertical_lines) < 2:
        print(f"[ERROR] Not enough vertical lines (need 2, found {len(vertical_lines)})")
        return None, None
    
    if len(horizontal_lines) < 2:
        print(f"[ERROR] Not enough horizontal lines (need 2, found {len(horizontal_lines)})")
        return None, None
    
    # STEP 9: Select OUTERMOST lines (not center lines like net)
    
    # For vertical lines: pick leftmost and rightmost
    left_verticals = [l for l in vertical_lines if min(l[0], l[2]) < w // 3]
    right_verticals = [l for l in vertical_lines if max(l[0], l[2]) > 2 * w // 3]
    
    # For horizontal lines: pick topmost and bottommost (avoid middle)
    top_horizontals = [l for l in horizontal_lines if min(l[1], l[3]) < h // 3]
    bottom_horizontals = [l for l in horizontal_lines if max(l[1], l[3]) > 2 * h // 3]
    
    print(f"[DEBUG] Filtered - Left: {len(left_verticals)}, Right: {len(right_verticals)}, Top: {len(top_horizontals)}, Bottom: {len(bottom_horizontals)}")
    
    if not (left_verticals and right_verticals and top_horizontals and bottom_horizontals):
        print("⚠ Could not find all 4 boundary lines in expected regions")
        print("[INFO] Attempting alternative selection strategy...")
        
        # Alternative: Sort all lines by position and pick extremes
        vertical_lines.sort(key=lambda x: min(x[0], x[2]))  # Sort by leftmost x
        horizontal_lines.sort(key=lambda x: min(x[1], x[3]))  # Sort by topmost y
        
        if len(vertical_lines) >= 2 and len(horizontal_lines) >= 2:
            left_line = vertical_lines[0][:4]  # Leftmost
            right_line = vertical_lines[-1][:4]  # Rightmost
            top_line = horizontal_lines[0][:4]  # Topmost
            bottom_line = horizontal_lines[-1][:4]  # Bottommost
        else:
            print("❌ Could not find all 4 boundary lines")
            return None, None
    else:
        # Select the most extreme lines (closest to edges)
        left_line = min(left_verticals, key=lambda x: min(x[0], x[2]))[:4]
        right_line = max(right_verticals, key=lambda x: max(x[0], x[2]))[:4]
        top_line = min(top_horizontals, key=lambda x: min(x[1], x[3]))[:4]
        bottom_line = max(bottom_horizontals, key=lambda x: max(x[1], x[3]))[:4]
    
    # Draw selected boundary lines
    boundary_debug = img.copy()
    cv2.line(boundary_debug, (left_line[0], left_line[1]), (left_line[2], left_line[3]), (255, 0, 0), 3)
    cv2.line(boundary_debug, (right_line[0], right_line[1]), (right_line[2], right_line[3]), (255, 0, 0), 3)
    cv2.line(boundary_debug, (top_line[0], top_line[1]), (top_line[2], top_line[3]), (0, 255, 0), 3)
    cv2.line(boundary_debug, (bottom_line[0], bottom_line[1]), (bottom_line[2], bottom_line[3]), (0, 255, 0), 3)
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "03_boundary_lines_selected.jpg"), boundary_debug)
    
    # STEP 10: Find 4 corner intersections
    top_left = line_intersection(left_line, top_line)
    top_right = line_intersection(right_line, top_line)
    bottom_right = line_intersection(right_line, bottom_line)
    bottom_left = line_intersection(left_line, bottom_line)
    
    corners = [top_left, top_right, bottom_right, bottom_left]
    
    # Validate corners
    valid_corners = []
    for c in corners:
        if c is not None:
            x, y = c
            # Allow corners slightly outside image (perspective distortion)
            if -w*0.1 <= x < w*1.1 and -h*0.1 <= y < h*1.1:
                valid_corners.append(c)
    
    if len(valid_corners) != 4:
        print(f"⚠ Could not find exactly 4 valid corners (found {len(valid_corners)})")
        print(f"[DEBUG] Corners: {corners}")
        return None, None
    
    print(f"[✓] Found 4 corners of FULL court")
    print(f"[DEBUG] Corners: TL={top_left}, TR={top_right}, BR={bottom_right}, BL={bottom_left}")
    
    # STEP 11: Order corners and create hulls
    inner_hull = order_points_clockwise(np.array(valid_corners)).astype(np.int32)
    outer_hull = offset_polygon(inner_hull, offset=50)
    
    # STEP 12: Draw boundaries on grayscale image for visualization
    gray_with_boundary = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    cv2.polylines(gray_with_boundary, [inner_hull], True, (0, 255, 0), 3)
    cv2.polylines(gray_with_boundary, [outer_hull], True, (0, 0, 255), 3)
    
    # Draw corners
    for i, corner in enumerate(inner_hull):
        cv2.circle(gray_with_boundary, tuple(corner), 10, (255, 0, 255), -1)
        cv2.putText(gray_with_boundary, f"C{i}", (corner[0]+15, corner[1]-10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "03_gray_boundary.jpg"), gray_with_boundary)
    
    return inner_hull, outer_hull