import cv2
import numpy as np
import os
from config import OUTPUT_IMAGES_DIR

# ============================================================
# ENHANCED INNER LINE DETECTION - HANDLES NEAR-CAMERA LINES
# ============================================================

def detect_inner_lines(img, inner_hull, detect_short_lines=True):
    """
    Enhanced line detection that captures vertical lines near the camera.
    These lines appear shorter due to perspective distortion.
    
    Args:
        img: Original input image
        inner_hull: 4 corner points of the court boundary
        detect_short_lines: Enable detection of shorter lines (near camera)
    
    Returns:
        vertical_td: List of vertical lines
        horizontal_td: List of horizontal lines (NO NET)
        H_inv: Inverse homography matrix
    """
    
    print("[...] Enhanced Line Detection (including near-camera lines)")
    
    # Create homography transformation
    dst = np.array([[0, 0], [600, 0], [600, 1200], [0, 1200]], dtype=np.float32)
    H, _ = cv2.findHomography(inner_hull.astype(np.float32), dst)
    H_inv = np.linalg.inv(H)
    
    # Warp to top-down view
    warped = cv2.warpPerspective(img, H, (600, 1200))
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "04_warped_topdown.jpg"), warped)
    
    # Enhanced preprocessing for better line detection
    gray = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
    
    # Apply strong CLAHE for maximum contrast
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    gray_enhanced = clahe.apply(gray)
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "04_enhanced_contrast.jpg"), gray_enhanced)
    
    # Multiple thresholding strategies
    _, bw_high = cv2.threshold(gray_enhanced, 200, 255, cv2.THRESH_BINARY)
    _, bw_otsu = cv2.threshold(gray_enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    _, bw_low = cv2.threshold(gray_enhanced, 160, 255, cv2.THRESH_BINARY)  # Lower threshold
    
    # Combine thresholds
    bw = cv2.bitwise_or(bw_high, bw_otsu)
    bw = cv2.bitwise_or(bw, bw_low)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "04_combined_threshold.jpg"), bw)
    
    # Edge detection with multiple parameters
    edges1 = cv2.Canny(bw, 50, 150, apertureSize=3)
    edges2 = cv2.Canny(bw, 30, 100, apertureSize=3)  # More sensitive
    edges = cv2.bitwise_or(edges1, edges2)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "04_combined_edges.jpg"), edges)
    
    # STRATEGY 1: Detect LONG lines (baseline, service lines at distance)
    print("[INFO] Pass 1: Detecting long lines...")
    lines_long = cv2.HoughLinesP(
        edges, 1, np.pi/180,
        threshold=80,
        minLineLength=120,  # Long lines
        maxLineGap=40
    )
    
    # STRATEGY 2: Detect SHORT lines (near camera, perspective-compressed)
    print("[INFO] Pass 2: Detecting short lines (near camera)...")
    lines_short = cv2.HoughLinesP(
        edges, 1, np.pi/180,
        threshold=40,        # Lower threshold for weaker lines
        minLineLength=50,    # Much shorter minimum length
        maxLineGap=25        # Smaller gap tolerance
    )
    
    # STRATEGY 3: Focus on top region where camera-near lines appear
    print("[INFO] Pass 3: Focused detection on top region...")
    h_warped, w_warped = warped.shape[:2]
    top_region = int(h_warped * 0.3)  # Top 30% of image
    
    edges_top = edges[:top_region, :].copy()
    lines_top = cv2.HoughLinesP(
        edges_top, 1, np.pi/180,
        threshold=30,        # Even more sensitive
        minLineLength=40,    # Very short lines OK
        maxLineGap=20
    )
    
    # Combine all detected lines
    all_lines = []
    
    if lines_long is not None:
        all_lines.extend(lines_long)
        print(f"[INFO] Long lines detected: {len(lines_long)}")
    
    if lines_short is not None:
        all_lines.extend(lines_short)
        print(f"[INFO] Short lines detected: {len(lines_short)}")
    
    if lines_top is not None:
        # Adjust y-coordinates for top region lines
        lines_top_adjusted = []
        for line in lines_top:
            x1, y1, x2, y2 = line[0]
            lines_top_adjusted.append([[x1, y1, x2, y2]])
        all_lines.extend(lines_top_adjusted)
        print(f"[INFO] Top region lines detected: {len(lines_top)}")
    
    if not all_lines:
        print("[WARNING] No lines detected!")
        return [], [], H_inv
    
    print(f"[INFO] Total raw line segments: {len(all_lines)}")
    
    # Classify lines as vertical or horizontal
    raw_vertical = []
    raw_horizontal = []
    
    line_debug = warped.copy()
    
    for line in all_lines:
        x1, y1, x2, y2 = line[0]
        angle = abs(np.degrees(np.arctan2(y2-y1, x2-x1)))
        length = np.hypot(x2 - x1, y2 - y1)
        
        # More lenient angle tolerance for short lines
        if 82 < angle < 98:  # Vertical lines (wider tolerance)
            raw_vertical.append((x1, y1, x2, y2))
            cv2.line(line_debug, (x1, y1), (x2, y2), (255, 0, 0), 1)
            
        elif angle < 8 or angle > 172:  # Horizontal lines (wider tolerance)
            raw_horizontal.append((x1, y1, x2, y2))
            cv2.line(line_debug, (x1, y1), (x2, y2), (0, 255, 0), 1)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "04_raw_segments_all.jpg"), line_debug)
    
    print(f"[INFO] Raw segments: {len(raw_vertical)} vertical, {len(raw_horizontal)} horizontal")
    
    # Enhanced merging with more aggressive parameters for short lines
    print("[...] Merging line segments...")
    merged_vertical = smart_merge_lines_enhanced(
        raw_vertical, 
        orientation='vertical', 
        warped_shape=warped.shape,
        gap_threshold=50,      # Larger gap for near-camera lines
        position_tolerance=15  # More tolerance for alignment
    )
    
    merged_horizontal = smart_merge_lines_enhanced(
        raw_horizontal, 
        orientation='horizontal', 
        warped_shape=warped.shape,
        gap_threshold=40,
        position_tolerance=12
    )
    
    # Visualization of merged lines
    merged_debug = warped.copy()
    for line in merged_vertical:
        x1, y1, x2, y2 = line
        cv2.line(merged_debug, (x1, y1), (x2, y2), (255, 0, 0), 2)
        # Draw length label
        mid_x, mid_y = (x1 + x2) // 2, (y1 + y2) // 2
        length = int(np.hypot(x2 - x1, y2 - y1))
        cv2.putText(merged_debug, f"{length}", (mid_x + 5, mid_y),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 0), 1)
    
    for line in merged_horizontal:
        x1, y1, x2, y2 = line
        cv2.line(merged_debug, (x1, y1), (x2, y2), (0, 255, 0), 2)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "04_merged_all_lines.jpg"), merged_debug)
    
    print(f"[INFO] After merging: {len(merged_vertical)} vertical, {len(merged_horizontal)} horizontal")
    
    # FILTER OUT NET LINE from horizontal lines
    mid_y = h_warped // 2
    net_exclusion_zone = 100
    
    horizontal_td = []
    net_debug = warped.copy()
    
    for line in merged_horizontal:
        x1, y1, x2, y2 = line
        line_center_y = (y1 + y2) // 2
        distance_from_center = abs(line_center_y - mid_y)
        
        if distance_from_center < net_exclusion_zone:
            cv2.line(net_debug, (x1, y1), (x2, y2), (0, 0, 255), 3)
            cv2.putText(net_debug, "NET", (x1 + 10, y1 - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
        else:
            horizontal_td.append(line)
            cv2.line(net_debug, (x1, y1), (x2, y2), (0, 255, 0), 2)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "04_net_filtering.jpg"), net_debug)
    
    # Remove duplicate lines with enhanced deduplication
    vertical_td = remove_duplicate_lines_enhanced(merged_vertical, orientation='vertical')
    horizontal_td = remove_duplicate_lines_enhanced(horizontal_td, orientation='horizontal')
    
    # Final visualization with line labels
    final_debug = warped.copy()
    
    for i, line in enumerate(vertical_td):
        x1, y1, x2, y2 = line
        cv2.line(final_debug, (x1, y1), (x2, y2), (255, 0, 0), 3)
        mid_x = (x1 + x2) // 2
        mid_y = (y1 + y2) // 2
        cv2.putText(final_debug, f"V{i}", (mid_x + 5, mid_y),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 2)
    
    for i, line in enumerate(horizontal_td):
        x1, y1, x2, y2 = line
        cv2.line(final_debug, (x1, y1), (x2, y2), (0, 255, 0), 3)
        mid_x = (x1 + x2) // 2
        mid_y = (y1 + y2) // 2
        cv2.putText(final_debug, f"H{i}", (mid_x + 5, mid_y),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 2)
    
    cv2.imwrite(os.path.join(OUTPUT_IMAGES_DIR, "04_final_labeled_lines.jpg"), final_debug)
    
    print(f"[✓] Final: {len(vertical_td)} vertical, {len(horizontal_td)} horizontal")
    
    # Print vertical line positions for debugging
    print("\n[DEBUG] Vertical line X-positions:")
    for i, line in enumerate(vertical_td):
        x_pos = (line[0] + line[2]) // 2
        length = int(np.hypot(line[2] - line[0], line[3] - line[1]))
        y_range = f"y={min(line[1], line[3])}-{max(line[1], line[3])}"
        print(f"  V{i}: x={x_pos}, length={length}px, {y_range}")
    
    return vertical_td, horizontal_td, H_inv


def smart_merge_lines_enhanced(lines, orientation='horizontal', warped_shape=(1200, 600),
                               gap_threshold=40, position_tolerance=12):
    """
    Enhanced merging with better handling of short near-camera lines.
    """
    
    if not lines:
        return []
    
    # Convert to structured format
    line_data = []
    for line in lines:
        x1, y1, x2, y2 = line
        length = np.hypot(x2 - x1, y2 - y1)
        
        if orientation == 'horizontal':
            min_x = min(x1, x2)
            max_x = max(x1, x2)
            avg_y = (y1 + y2) / 2
            line_data.append({
                'min_x': min_x, 'max_x': max_x, 'y': avg_y,
                'length': length, 'merged': False
            })
        else:
            min_y = min(y1, y2)
            max_y = max(y1, y2)
            avg_x = (x1 + x2) / 2
            line_data.append({
                'min_y': min_y, 'max_y': max_y, 'x': avg_x,
                'length': length, 'merged': False
            })
    
    merged_lines = []
    
    # Sort by position (helps with merging)
    if orientation == 'horizontal':
        line_data.sort(key=lambda l: l['y'])
    else:
        line_data.sort(key=lambda l: l['x'])
    
    for i, line1 in enumerate(line_data):
        if line1['merged']:
            continue
        
        # Start a group
        group = [line1]
        line1['merged'] = True
        
        # Look for segments to merge
        for j, line2 in enumerate(line_data):
            if i == j or line2['merged']:
                continue
            
            if orientation == 'horizontal':
                # Check collinearity
                y_diff = abs(line1['y'] - line2['y'])
                if y_diff > position_tolerance:
                    continue
                
                # Check proximity in x
                gap = max(line1['min_x'], line2['min_x']) - min(line1['max_x'], line2['max_x'])
                
                # Special case: be more lenient with short lines
                if line2['length'] < 80:  # Short line (likely near camera)
                    effective_gap_threshold = gap_threshold * 1.5
                else:
                    effective_gap_threshold = gap_threshold
                
                if gap <= effective_gap_threshold:
                    group.append(line2)
                    line2['merged'] = True
            
            else:  # vertical
                # Check collinearity
                x_diff = abs(line1['x'] - line2['x'])
                if x_diff > position_tolerance:
                    continue
                
                # Check proximity in y
                gap = max(line1['min_y'], line2['min_y']) - min(line1['max_y'], line2['max_y'])
                
                # Be more lenient with short lines
                if line2['length'] < 80:
                    effective_gap_threshold = gap_threshold * 1.5
                else:
                    effective_gap_threshold = gap_threshold
                
                if gap <= effective_gap_threshold:
                    group.append(line2)
                    line2['merged'] = True
        
        # Create merged line
        if orientation == 'horizontal':
            min_x = min(seg['min_x'] for seg in group)
            max_x = max(seg['max_x'] for seg in group)
            avg_y = int(np.mean([seg['y'] for seg in group]))
            merged_lines.append((min_x, avg_y, max_x, avg_y))
        else:
            min_y = min(seg['min_y'] for seg in group)
            max_y = max(seg['max_y'] for seg in group)
            avg_x = int(np.mean([seg['x'] for seg in group]))
            merged_lines.append((avg_x, min_y, avg_x, max_y))
    
    return merged_lines


def remove_duplicate_lines_enhanced(lines, orientation='horizontal', min_distance=40):
    """
    Enhanced duplicate removal that preserves short near-camera lines.
    """
    
    if not lines:
        return []
    
    # Sort lines by position
    if orientation == 'horizontal':
        sorted_lines = sorted(lines, key=lambda l: (l[1] + l[3]) / 2)
    else:
        sorted_lines = sorted(lines, key=lambda l: (l[0] + l[2]) / 2)
    
    unique = [sorted_lines[0]]
    
    for line in sorted_lines[1:]:
        if orientation == 'horizontal':
            current_pos = (line[1] + line[3]) / 2
            last_pos = (unique[-1][1] + unique[-1][3]) / 2
        else:
            current_pos = (line[0] + line[2]) / 2
            last_pos = (unique[-1][0] + unique[-1][2]) / 2
        
        distance = abs(current_pos - last_pos)
        
        # Calculate line lengths
        current_length = np.hypot(line[2] - line[0], line[3] - line[1])
        last_length = np.hypot(unique[-1][2] - unique[-1][0], 
                              unique[-1][3] - unique[-1][1])
        
        # If too close, keep the longer one
        if distance < min_distance:
            if current_length > last_length:
                unique[-1] = line
        else:
            unique.append(line)
    
    return unique