import numpy as np

# ============================================================
# GEOMETRY UTILITY FUNCTIONS
# ============================================================

def line_intersection(line1, line2):
    """Find intersection point of two lines"""
    x1, y1, x2, y2 = line1
    x3, y3, x4, y4 = line2
    
    denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(denom) < 1e-10:
        return None
    
    px = ((x1*y2 - y1*x2) * (x3 - x4) - (x1 - x2) * (x3*y4 - y3*x4)) / denom
    py = ((x1*y2 - y1*x2) * (y3 - y4) - (y1 - y2) * (x3*y4 - y3*x4)) / denom
    
    return int(px), int(py)


def order_points_clockwise(pts):
    """Order points in clockwise order: TL, TR, BR, BL"""
    pts = np.array(pts, dtype=np.float32)
    
    # Sort by y-coordinate
    sorted_by_y = pts[np.argsort(pts[:, 1])]
    
    # Top two points
    top_pts = sorted_by_y[:2]
    top_pts = top_pts[np.argsort(top_pts[:, 0])]
    
    # Bottom two points
    bottom_pts = sorted_by_y[2:]
    bottom_pts = bottom_pts[np.argsort(bottom_pts[:, 0])]
    
    return np.array([top_pts[0], top_pts[1], bottom_pts[1], bottom_pts[0]], dtype=np.float32)


def offset_polygon(points, offset=50):
    """Expand polygon outward by a fixed pixel amount"""
    pts = np.array(points, dtype=np.float32)
    center = np.mean(pts, axis=0)
    vecs = pts - center
    norms = np.linalg.norm(vecs, axis=1).reshape(-1, 1)
    norms[norms == 0] = 1
    unit = vecs / norms
    return (pts + unit * offset).astype(np.int32)


def intersect_lines(l1, l2):
    """Find intersection of two lines"""
    x1, y1, x2, y2 = l1
    x3, y3, x4, y4 = l2
    A = np.array([[x2-x1, x3-x4],
                  [y2-y1, y3-y4]])
    if abs(np.linalg.det(A)) < 1e-6:
        return None
    B = np.array([x3-x1, y3-y1])
    t = np.linalg.solve(A, B)[0]
    return int(x1 + t*(x2-x1)), int(y1 + t*(y2-y1))


def deduplicate_points(points, dist_thresh=25):
    """Remove duplicate points within threshold distance"""
    unique = []
    for p in points:
        if not any(np.hypot(p[0]-q[0], p[1]-q[1]) < dist_thresh for q in unique):
            unique.append(p)
    return unique